[![GitHub release](https://img.shields.io/github/release/im85288/service.upnext.svg)](https://github.com/im85288/service.upnext/releases)
[![CI](https://github.com/im85288/service.upnext/workflows/CI/badge.svg)](https://github.com/im85288/service.upnext/actions?query=workflow:CI)
[![Codecov status](https://img.shields.io/codecov/c/github/im85288/service.upnext/master)](https://codecov.io/gh/im85288/service.upnext/branch/master)
[![License: GPLv2](https://img.shields.io/badge/License-GPLv2-yellow.svg)](https://opensource.org/licenses/GPL-2.0)
[![Contributors](https://img.shields.io/github/contributors/im85288/service.upnext.svg)](https://github.com/im85288/service.upnext/graphs/contributors)
[![Greptile: The War on Bugs](https://www.greptile.com/badge.svg)](https://www.greptile.com/?utm_source=oss_badge&utm_medium=readme&utm_campaign=greptile_for_open_source)

# Up Next - Proposes to play the next episode automatically

This Kodi add-on shows a Netflix-style notification for watching the next episode. After a few automatic iterations it asks the user if they are still watching.

A lot of existing add-ons already integrate with this service out-of-the-box.

## Settings
The add-on has various settings to fine-tune the experience, however the default settings should be fine for most.

  * Simple or fancy mode (defaults to fancy mode, but a more simple interface is possible)
  * Optional OK/Select access to playback controls alongside the next-episode popup. Press an arrow first to select Watch now or Close; press Up to return to playback-control focus. If Kodi hides the popup while controls are open, it is restored when the controls close. Normal episode-end advancement remains active.
  * With the optional arrow-seeking mode enabled, arrows seek the video while playback controls have focus. Use the Context Menu action to switch between playback focus and the popup buttons; on some remotes this is a long press of OK. The default arrow behavior is unchanged when the option is disabled.
  * The notification time can be adjusted (defaults to 30 seconds before the end)
  * A credits delay can advance early when the provider supplies a credits offset (disabled by default). Back cancels the countdown and keeps the current episode playing; Pause freezes it with the video.
  * The default action can be configured, i.e. should it advance to the next episode (default) when the user does not respond, or stop
  * With "Enable on playlists", videos outside the library (e.g. files started with "Play from here") get the popup for the next playlist item
  * Library episodes left early with Watch Now or the credits delay are marked as watched (enabled by default)
  * The number of episodes to play automatically before asking the user if they are still there (defaults to 3 episodes)

> NOTE: The add-on settings are found in the Kodi add-ons section, in the *Services* category.

Credits autoplay uses the provider's absolute `notification_offset`; it does not detect credits from the video. Enable it only when those timestamps match the stream, as an early transition can skip post-credits scenes. Leave the delay at 0 to keep normal episode-end playback and use Next Episode to advance manually.

For [Addon Integration](https://github.com/im85288/service.upnext/wiki/Integration) and [Skinners](https://github.com/im85288/service.upnext/wiki/Skinners) see the [wiki](https://github.com/im85288/service.upnext/wiki)

## Releases

### v1.3.7 (2026-11-10)
- Fix the service failing to start on Xbox (Kodi from the Microsoft Store), reported by @barlafuus83 (@im85288)
- Update Simplified Chinese translation (@wabisabi926)

### v1.3.6 (2026-11-04)
- Optionally seek with the arrow keys while the popup is open (with OK/Select playback controls on); the Context Menu action, a long press of OK on some remotes, switches between seeking and the popup buttons (@Drahy)
- Optionally pause the current video while an add-on starts the next episode, so the end of the episode isn't missed during a slow source search (off by default) (@notoco)
- Bring back an open popup that Kodi hid while the device was asleep (@Drahy)
- Complete the Czech translation, including the add-on summary and description (@Drahy)
- Update Polish translation (@notoco)

### v1.3.5 (2026-11-03)
- Continue a partly watched next library episode from where it was left, instead of from the start (setting on by default; idea from MoojMidge's fork) (@im85288)
- Show the countdown in minutes and seconds when the popup opens more than a minute before it acts (e.g. from an add-on's or the credits' timing), and spread the simple popup's ring over the whole countdown, instead of showing no time until the last minute (@im85288)
- Follow Kodi's "Show information for unwatched items" setting in the popup: hide the plot and/or picture of an unwatched next episode when Kodi hides them (@im85288)
- Fall back to season art, or to add-on art without the tvshow. prefix, when the show has no fanart, landscape, poster, clearart or clearlogo (@im85288)

### v1.3.4 (2026-11-03)
- Update Simplified Chinese translation (@wabisabi926)

### v1.3.3 (2026-11-02)
- With "Enable on playlists" on, show the popup for videos that aren't library episodes when they play from a playlist with a next item, e.g. files started with "Play from here" (@im85288)
- Mark a library episode as watched, and clear its resume point, when Watch Now or the credits delay moves on before Kodi counts it as watched (optional, on by default) (@im85288)
- Read settings from one cached copy, reloaded when they change, instead of loading them from disk several times a second during playback (@im85288)
- Allow notification times of up to 300 seconds before the end, for episodes with long credits (@notoco)
- Update the Polish translation, and shorten labels that didn't fit in the settings dialog (@notoco)

### v1.3.2 (2026-11-01)
- Optionally ask whether playback should continue after a chosen amount of active viewing time or during the bedtime window, from the configured time until 06:00, at the next episode transition. Recheck limits while the next-episode popup is open and preserve the timer through sleep, including delayed sleep notifications. Time spent paused, buffering or seeking does not count; confirming the prompt resets the viewing timer and acknowledges bedtime for that night within the current playback session. Both options are disabled by default (@Drahy)

### v1.3.1 (2026-11-01)
- Optionally let OK/Select open Kodi's playback controls alongside the next-episode popup in both styles, including existing skin overrides. Arrow navigation enters its normal buttons, and Up returns to playback-control focus. Restore a popup hidden by Kodi after the playback controls close; preserve normal episode-end advancement, Stop, Back and Still Watching behavior (@Drahy)
- Fix the popup not appearing for an episode an add-on starts with Player.play, when Kodi briefly reported it with the previous episode's position and duration (@im85288)
- Update Simplified Chinese translation (@wabisabi926)

### v1.3.0 (2026-10-24)
- Show a Skip intro / Skip recap button when an add-on marks those ranges in a new `skip_segments` field of `upnext_data`, with optional automatic skipping (@im85288)
- Faster popups for library episodes, especially for long-running shows, and cheaper logging (@im85288)
- Keep the service running when an episode's metadata is incomplete or the player isn't ready, instead of stopping Up Next until Kodi restarts (@im85288)
- Clear the `service.upnext.dialog` window property when the popup closes because playback stopped or changed, so skins no longer see it as still open (@im85288)

### v1.2.3 (2026-10-21)
- Close the popup when another episode starts while it is open, so its countdown can no longer skip into the next episode of the old one (@im85288)

### v1.2.2 (2026-10-21)
- Optionally advance during provider-supplied credits after a configurable delay, show the actual countdown and Back cancellation hint in both popup styles, and preserve normal episode-end playback when credits metadata is unavailable (@Drahy)
- Keep tracking an episode that started while the previous popup was open, so it still gets its own prompt (@im85288)

### v1.2.1 (2026-10-20)
- Fix the popup failing to fill in when an add-on sends a partial or missing first-aired date (@im85288)
- Add Simplified Chinese translation (@wabisabi926)

### v1.2.0 (2026-10-20)
- Drop support for Kodi 18 (Leia); Up Next now requires Kodi 19 (Matrix) or later (@im85288)
- Remove Python 2 compatibility code, and fix looking up a TV show by title on Python 3 (@im85288)
- Use gender-neutral wording in the description (@wedebe)
- Fix empty GitHub release notes and add a manual Kodi submission workflow (@im85288)

### v1.1.10 (2026-10-20)
- Stop playback once after closing the popup and preserve playback started while it was open (@Drahy)
- Back dismisses the Up Next and Still Watching prompts without stopping the video (@Drahy)
- Restore next-episode tracking, metadata and the Still Watching count after sleep, and keep tracking through temporary player errors (@Drahy)
- Fix potential loss of queue state due to pre-emptive queue reset (@MoojMidge)
- Workaround for Trakt playlist monitoring (@MoojMidge)
- Use localised date in popups (@MoojMidge)
- Use Python 2 compatible super() call in monitor (@rainman74)
- Update Finnish translation (@olavinto)
- Update Spanish add-on description (@roliverosc)
- Update CI workflows (@MoojMidge, @im85288)

### v1.1.9 (2023-05-10)
- Fix handling of non-ASCII filenames for Kodi18 (@MoojMidge)
- Fix failing ci workflow (@MoojMidge)
- Update Swedish translation (@Sopor)
- Explicitly set sonarcloud coverage path (@MoojMidge)
- Fix error when kodi is not playing video any longer (@AnonTester)

### v1.1.8 (2022-09-13)
- Never ask if Still Watching? if playedInARow is 0 (@MoojMidge)
- Still Watching? checks number of plays not number+1 (@MoojMidge)

### v1.1.7 (2022-09-03)
- Update check for filename of multi-part episodes (@MoojMidge)
- Check for physical disc or disc image being played (@MoojMidge)
- Translation update to Russian (@ArtyIF)
- Fix CI workflow (@MoojMidge)

### v1.1.6 (2022-03-07)
- Fix for missing mediatype video info with addon video content (@MoojMidge)
- Translation updates to Croatian, Japanese, Korean, Swedish and Finnish (@dsardelic, @Thunderbird2086, @Sopor, @Dis90)
- New translation for Taiwanese Mandarin (@JuenTingShie)
- Use onAVStarted instead of onPlayBackStarted (@MoojMidge)
- Fix for Kodi not using the video player/playlist to play videos (@MoojMidge)
- Fixes misalignment of system.time and endtime (@jojobrogess)

### v1.1.5 (2021-02-21)
- Fix playlists to work with non-library content (@MoojMidge)
- Fix to prevent unwanted playback when using playlist queueing method (@MoojMidge)
- New translation for Finnish (@Dis90)

### v1.1.4 (2020-12-03)
- Fix problem causing pop-up to not appear (@MoojMidge)
- Translation updates to Romanian, Russian and Spanish (@tmihai20, @vlmaksime, @roliverosc)

### v1.1.3 (2020-10-14)
- Enable customPlayTime by default (@dagwieers)
- Do not seek to the end before playing next episode (@dagwieers)
- Add Kodi v17 compatibility (@dagwieers)
- Fix logging on Kodi v19 (Matrix) after recent breakage (@MoojMidge)
- Enqueue the next episode in the playlist (@MoojMidge)
- Translation updates to German (@tweimer)

### v1.1.2 (2020-06-22)
- Small bugfix release (@im85288)
- Translation updates to Japanese and Korean (@Thunderbird2086)

### v1.1.1 (2020-06-21)
- Avoid conflict with external players (@BrutuZ)
- Restore "Ignore Playlist" option (@BrutuZ)
- Fix a known Kodi bug related to displaying hours (@Maven85)
- Improvements to endtime visualization (@dagwieers)
- New translations for Hindi and Romanian (@tahirdon, @tmihai20)
- Translation updates to Hungarian and Spanish (@frodo19, @roliverosc)

### v1.1.0 (2020-01-17)
- Add notification_offset for Netflix add-on (@CastagnaIT)
- Fix various runtime exceptions (@thebertster)
- Implement new settings (@dagwieers)
- Implement new developer mode (@dagwieers)
- Show current time and next endtime in notification (@dagwieers)
- New translations for Brazilian, Czech, Greek, Japanese, Korean (@mediabrasiltv, @svetlemodry, @Twilight0, @Thunderbird2086)
- New translations for Russian, Slovak, Spanish, Swedish (@vlmaksime, @matejmosko, @sagatxxx, @Sopor)
- Translation updates to Croatian, French, German, Hungarian, Italian, Polish (@arvvoid, @zecakeh, @tweimer, @frodo19, @EffeF, @notoco)

### v1.0.7 (2019-12-03)
- Add Up Next in the program add-on section (@dagwieers)
- Update add-on icon to use black background (@dagwieers)
- Fix 24-hour format based on Kodi setting (@dagwieers)
- New translations for Croatian (@arvvoid)
- Translation updates to French, Hungarian, Italian and Polish (@mediaminister, @frodo19, @EffeF, @notoco)

### v1.0.6 (2019-11-26)
- Implement base64 encoding to support newer AddonSignals (@dagwieers)
- Fixes to Python 3.5 support (@anxdpanic)
- Add SPDX identifier for license (@dagwieers)
- Translation updates to German (@tweimer)

### v1.0.5 (2019-11-19)
- Translation fixes (@dagwieers)

### v1.0.4 (2019-11-19)
- Automatic stop playing as option (@notoco)
- Fix exception when add-on is exited (@dagwieers)
- Fix playlist logic (@mediaminister)
- Add support for Python 3 and Kodi v19 (@mediaminister)
- Introduce "Close" button when configured in settings (@dagwieers)
- Add support for a Back-button action to dismiss Up Next pop-up (@dagwieers)
- Always reset state when playback finishes (@mediaminister)
- Various code improvements and fixes (@dagwieers, @mediaminister)
- New translations for Dutch (@dagwieers)
- Translation updates to German (@semool, @beatmasterRS)

### v1.0.3 (2019-07-30)
- Disable tracking for non episode (@angelblue05)

### v1.0.2 (2019-07-24)
- Add JSONRPC method (@angelblue05)
- Add priority to existing playlist (@angelblue05)
- Add endtime prop (@angelblue05)
- Remove enablePlaylist setting (@angelblue05)
